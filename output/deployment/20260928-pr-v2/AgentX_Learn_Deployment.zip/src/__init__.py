"""Employee training assistant application."""
