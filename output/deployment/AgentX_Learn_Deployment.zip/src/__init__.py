"""Employee training assistant application."""
